﻿using WeatherCLI.Dto;
namespace WeatherCLI;

internal class Forecast(OpenMetroApiClient openMetroApi)
{
	public async Task StartAsync()
	{
		
	}
}
