﻿using System.Buffers.Text;
using System.Text.Json;
using WeatherCLI.Dto;

namespace WeatherCLI;

internal class OpenMetroApiClient(IHttpClientFactory factory)
{
	private const string _Latitude = "49";
	private const string _Longitude = "8.44";

	private readonly HttpClient _client = factory.CreateClient("OpenMetro");

	public async Task<TemperatureForecast> GetTemperatureForecast(int pastDays, int forecastDays)
		=> new TemperatureForecast(await GetMetroResponse(pastDays, forecastDays));

	private async Task<OpenMetroResponse> GetMetroResponse(int pastDays, int forecastDays)
	{
		var forecastRequestString = $"forecast?latitude={_Latitude}&longitude={_Longitude}&hourly=temperature_2m&past_days={pastDays}&forecast_days={forecastDays}";

		var response = await _client.GetAsync(forecastRequestString);

		if (response.IsSuccessStatusCode)
		{
			var responseString = await response.Content.ReadAsStringAsync();
			var metroResponse = JsonSerializer.Deserialize<OpenMetroResponse>(responseString);
			if (metroResponse != null)
				return metroResponse;
			else
				throw new InvalidDataException($"Could not convert {responseString} to {typeof(OpenMetroResponse)}");
		}

		int statusCode = (int)response.StatusCode;
		string? reason = response.ReasonPhrase;

		throw new HttpRequestException($"{statusCode} ({reason})");
	}
}
