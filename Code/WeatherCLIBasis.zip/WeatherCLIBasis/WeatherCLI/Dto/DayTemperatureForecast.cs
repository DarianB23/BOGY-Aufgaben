﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherCLI.Dto;

internal class DayTemperatureForecast
{
	private readonly DateOnly _day;
	private readonly List<(DateTime Time, double Temperature)> _timeTemperature = [];

	public DateOnly Day { get => _day; }
	public List<(DateTime Time, double Temperature)> TimeTemperature { get => _timeTemperature; }

	public DayTemperatureForecast(DateOnly day, List<DateTime> time, List<double> temperature)
	{
		_day = day;
		_timeTemperature = time.Zip(temperature).ToList();
	}
}
