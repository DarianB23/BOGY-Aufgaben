﻿using System;
using System.Collections.Generic;
using System.Text;

namespace WeatherCLI.Dto;

internal class TemperatureForecast
{
	private readonly List<DayTemperatureForecast> _dayTemperatureForecasts = [];

	public List<DayTemperatureForecast> DayTemperatureForecasts { get => _dayTemperatureForecasts; }

	public IEnumerable<DateOnly> Days { get => _dayTemperatureForecasts.Select(t => t.Day); }

	public TemperatureForecast(OpenMetroResponse response)
	{
		var time = response.Hourly.Time.Select(DateTime.Parse).ToList();
		var temperature = response.Hourly.Temperature2m;
		var timeTemperature = new Dictionary<DateTime, double>();
		for (int i = 0; i < time.Count; i++)
		{
			timeTemperature.Add(time[i], temperature[i]);
		}

		foreach (var date in time.Select(t => t.Date).Distinct())
		{
			var timesForDay = time.Where(time => time.Date.Equals(date)).ToList();
			var indexies = timesForDay.Select(t => time.IndexOf(t)).ToList();
			var temperaturesForDay = indexies.Select(i => temperature[i]).ToList();
			var day = new DateOnly(date.Year, date.Month, date.Day);

			_dayTemperatureForecasts.Add(
				new DayTemperatureForecast(day, timesForDay, temperaturesForDay)
			);
		}
	}

	public DayTemperatureForecast GetForecastForDay(DateOnly day)
		=> _dayTemperatureForecasts.First(t => t.Day == day);
}
