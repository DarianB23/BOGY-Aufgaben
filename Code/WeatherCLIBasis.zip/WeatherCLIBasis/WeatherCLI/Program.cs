﻿using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using WeatherCLI;
using WeatherCLI.Dto;

Console.OutputEncoding = System.Text.Encoding.UTF8;

var builder = new HostBuilder();

builder.ConfigureServices(services =>
{
	services.AddHttpClient("OpenMetro", client =>
	{
		client.BaseAddress = new Uri("https://api.open-meteo.com/v1/");
		client.DefaultRequestHeaders.Add("Accept", "application/json");
	});

	services.AddSingleton<OpenMetroApiClient>();
	services.AddSingleton<Forecast>();
});

var host = builder.Build();
var forecast = host.Services.GetRequiredService<Forecast>();
await forecast.StartAsync();